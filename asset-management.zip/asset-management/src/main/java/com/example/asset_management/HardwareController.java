package com.example.asset_management;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class HardwareController {

    @Autowired
    private HardwareService hardwareService;

    @GetMapping("/hardware")
    public String viewHardwarePage(Model model) {
        model.addAttribute("listHardware", hardwareService.getAllHardware());
        return "hardware";
    }

    @GetMapping("/showNewHardwareForm")
    public String showNewHardwareForm(Model model) {
        Hardware hardware = new Hardware();
        model.addAttribute("hardware", hardware);
        return "new_hardware";
    }

    @PostMapping("/saveHardware")
    public String saveHardware(@ModelAttribute("hardware") Hardware hardware) {
        hardwareService.saveHardware(hardware);
        return "redirect:/hardware";
    }

    @GetMapping("/showFormForUpdateHardware/{id}")
    public String showFormForUpdateHardware(@PathVariable(value = "id") long id, Model model) {
        Hardware hardware = hardwareService.getHardwareById(id);
        model.addAttribute("hardware", hardware);
        return "update_hardware";
    }

    @GetMapping("/deleteHardware/{id}")
    public String deleteHardware(@PathVariable(value = "id") long id) {
        this.hardwareService.deleteHardwareById(id);
        return "redirect:/hardware";
    }
}
