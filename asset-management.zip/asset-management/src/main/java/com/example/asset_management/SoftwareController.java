package com.example.asset_management;

import com.example.asset_management.Software;
import com.example.asset_management.SoftwareService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class SoftwareController {

    @Autowired
    private SoftwareService softwareService;

    @GetMapping("/software")
    public String viewSoftwarePage(Model model) {
        model.addAttribute("listSoftware", softwareService.getAllSoftware());
        return "software";
    }

    @GetMapping("/showNewSoftwareForm")
    public String showNewSoftwareForm(Model model) {
        Software software = new Software();
        model.addAttribute("software", software);
        return "new_software";
    }

    @PostMapping("/saveSoftware")
    public String saveSoftware(@ModelAttribute("software") Software software) {
        softwareService.saveSoftware(software);
        return "redirect:/software";
    }

    @GetMapping("/showFormForUpdateSoftware/{id}")
    public String showFormForUpdateSoftware(@PathVariable(value = "id") long id, Model model) {
        Software software = softwareService.getSoftwareById(id);
        model.addAttribute("software", software);
        return "update_software";
    }

    @GetMapping("/deleteSoftware/{id}")
    public String deleteSoftware(@PathVariable(value = "id") long id) {
        this.softwareService.deleteSoftwareById(id);
        return "redirect:/software";
    }
}