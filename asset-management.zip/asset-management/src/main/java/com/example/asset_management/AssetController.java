package com.example.asset_management;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class AssetController {

    @Autowired
    private SoftwareService softwareService;

    @Autowired
    private HardwareService hardwareService;

    @GetMapping("/")
    public String viewHomePage(Model model) {
        long softwareCount = softwareService.getAllSoftware().size();
        long hardwareCount = hardwareService.getAllHardware().size();
        model.addAttribute("softwareCount", softwareCount);
        model.addAttribute("hardwareCount", hardwareCount);
        return "index";
    }
}
