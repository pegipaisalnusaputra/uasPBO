package com.example.asset_management;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class HardwareService {
    @Autowired
    private HardwareRepository hardwareRepository;

    public List<Hardware> getAllHardware() {
        return hardwareRepository.findAll();
    }

    public void saveHardware(Hardware hardware) {
        hardwareRepository.save(hardware);
    }

    public Hardware getHardwareById(Long id) {
        Optional<Hardware> optional = hardwareRepository.findById(id);
        Hardware hardware = null;
        if (optional.isPresent()) {
            hardware = optional.get();
        } else {
            throw new RuntimeException("Hardware not found for id :: " + id);
        }
        return hardware;
    }

    public void deleteHardwareById(Long id) {
        hardwareRepository.deleteById(id);
    }
}
