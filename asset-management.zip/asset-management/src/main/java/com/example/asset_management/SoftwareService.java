package com.example.asset_management;

import jakarta.persistence.Access;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class SoftwareService {
    @Autowired
    private SoftwareRepository softwareRepository;

    public List<Software> getAllSoftware() {
        return softwareRepository.findAll();
    }

    public void saveSoftware(Software software) {
        softwareRepository.save(software);
    }

    public Software getSoftwareById(Long id) {
        Optional<Software> optional = softwareRepository.findById(id);
        Software software = null;
        if (optional.isPresent()) {
            software = optional.get();
        } else {
            throw new RuntimeException("Software not found for id :: " + id);
        }
        return software;
    }

    public void deleteSoftwareById(Long id) {
        softwareRepository.deleteById(id);
    }
}
